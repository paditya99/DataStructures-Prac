#include<iostream>
using namespace std;
int main(){
  int min,loc;
  int arr[6]={4,9,1,6,12,3};
  for(int i=0;i<6-1;i++){
    min=i;
    for(int j=i+1;j<6;j++){
       if(arr[j]<arr[min]){
          min=j;
          loc=j;
       }
    }
    int temp=arr[i];
    arr[i]=arr[min];
    arr[min]=temp;
  }

   for(int i=0;i<6;i++){
      cout<<arr[i]<<" ";
   }

}
