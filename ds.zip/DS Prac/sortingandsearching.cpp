#include<iostream>
using namespace std;
void binarysearch(int arr[],int data,int n){
   int mid,first=0,last=n-1;
   mid=(first+last)/2;
   while(first<=last){
        if(arr[mid]==data){
            cout<<"Element found";
            break;
        }
        else if(arr[mid]>data){
            last=mid-1;
        }
        else{
            first=mid+1;
        }
        mid=(first+last)/2;



   }
   if(first>last){
      cout<<"Element not found";
   }


}
void selectionsort(int arr[],int n){
   int min,p,i,j;
   for(i=0;i<n-1;i++){
    min=arr[i];
    p=i;
    for(j=i+1;j<n;j++){
        if(arr[j]<min){
            min=arr[j];
            p=j;
        }

    }
    int temp=arr[i];
    arr[i]=arr[p];
    arr[p]=temp;

   }

}
void bubblesort(int arr[],int n){
   for(int i=0;i<n-1;i++){
      int swap=0;
      for( int j=0;j<(n-i);j++){
        if(arr[j+1]<arr[j]){
            int temp=arr[j];
            arr[j]=arr[j+1];
            arr[j+1]=temp;
            swap=1;
        }
      }
      if(swap==0){
        break;
      }
   }


}

void insertionsort(int arr[],int n){
   for(int i=0;i<n;i++){
    int temp=arr[i];
    int j=i-1;
    while(j>=0 && arr[j]>temp){
        arr[j]=arr[j+1];
        j--;
     }
     arr[j+1]=temp;

   }

}

void quick(int arr[],int n,int beg,int end,int *loc){
   int left=beg,right=end,temp;
   *loc=beg;
 step2:
   while(arr[*loc]<=arr[right] && *loc!=right){
    right--;
     }
    if(*loc==right){
        return;
    }
    if(arr[*loc]>arr[right]){
        temp=arr[*loc];
        arr[*loc]=arr[right];
        arr[right]=temp;
        *loc=right;
    }
    goto step3;
 step3:
  while(arr[left]<=arr[*loc] && left!=*loc){
        left++;
  }
  if(*loc==left){
    return;
  }
  if(arr[left]>arr[*loc]){
    temp=arr[left];
    arr[left]=arr[*loc];
    arr[*loc]=temp;
    *loc=left;
  }
  goto step2;


}


void merge(int arr[],int l,int m,int r){
    int i,j,k;
   int n1=m+1-l;
   int n2=r-m;
   int L[n1],R[n2];
   for(i=0;i<n1;i++){
      L[i]=arr[i+l];
   }
   for(j=0;j<n2;j++){
      R[j]=arr[j+m+1];
   }
  i=0,j=0,k=l;
   while(i<n1 && j<n2){
    if(L[i]<=R[j]){
        arr[k]=L[i];
        i++;
    }
    else{
        arr[k]=R[j];
        j++;
    }
    k++;
   }
   while(i<n1){
    arr[k]=L[i];
    i++;
    k++;
   }
   while(j<n2){
    arr[k]=R[j];
    j++;
    k++;
   }


}

void mergesort(int arr[],int l,int r){
    if(l<r){
        int m=(l+r-1)/2;
   mergesort(arr,l,m);
   mergesort(arr,m+1,r);
   merge(arr,l,m,r);
    }
}

void quicksort(int arr[],int n){
   int top=-1,beg,end,loc;
   int lower[10],upper[10];
   if(n>1){
    top++;
    lower[top]=0;
    upper[top]=n-1;
   }
   while(top!=-1){
    beg=lower[top];
    end=upper[top];
    top--;
    quick(arr,n,beg,end,&loc);
    if(beg<loc-1){
        top++;
        lower[top]=beg;
        upper[top]=loc-1;
    }
    if(loc+1<end){
        top++;
        lower[top]=loc+1;
        upper[top]=end;

    }
   }

}

int main(){
  int n,arr[50],data,i;
  cout<<"Enter the number of elements in the array: ";
  cin>>n;
  cout<<"\nEnter the elements: ";
  for(i=0;i<n;i++){
    cin>>arr[i];
  }
  /*
  cout<<"\nEnter the element you want to search: ";
  cin>>data;
  binarysearch(arr,data,n);
  cout<<"\n";
  */
  selectionsort(arr,n);
 for(i=0;i<n;i++){
    cout<<arr[i]<<" ";
   }
   cout<<"\n";
   bubblesort(arr,n);
   for(i=0;i<n;i++){
    cout<<arr[i]<<" ";
   }
   cout<<"\n";
   insertionsort(arr,n);

   for(i=0;i<n;i++){
    cout<<arr[i]<<" ";
   }
   cout<<"\n";
   quicksort(arr,n);

   for(i=0;i<n;i++){
    cout<<arr[i]<<" ";
   }
    cout<<"\n";
   mergesort(arr,0,n-1);

   for(i=0;i<n;i++){
    cout<<arr[i]<<" ";
   }

}
