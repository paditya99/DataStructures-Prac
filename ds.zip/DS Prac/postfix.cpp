#include<iostream>
using namespace std;
class stack{
   public:
       char s[100];
       int tos=-1;

  void push(char element){
  if(tos==100){
    cout<<"Stack is full";
  }

  else{
    tos++;
    s[tos]=element;
  }
}

char pop(){
   if(tos==-1){
    cout<<"stack is empty";
   }
   else{
      tos--;
      return s[tos];
   }

}

char top(){
   if(tos==-1){
    cout<<"stack is empty";
   }
   else{
    return s[tos];
   }
}

    int prec(char c)
  {
    if(c == '^')
    return 3;
    else if(c == '*' || c == '/')
    return 2;
    else if(c == '+' || c == '-')
    return 1;
    else
    return -1;
  }






};


int main()
{
    stack stk;
    string exp = "A+(B+(C*D)/E)";
    string s;
    char c;
    int i;

    stk.push('$');

    for(i=0;i<exp.length();i++){
        if(exp[i]=='('){
            stk.push('(');
        }
        else if((exp[i] >= 'a' && exp[i] <= 'z')||(exp[i] >= 'A' && exp[i] <= 'Z')){
            s+=exp[i];
        }
       else if(exp[i]==')'){
           while(stk.top()!='$' && stk.top()!='('){
               c=stk.top();
               stk.pop();
               s+=c;
           }
            if(stk.top() == '(')
            {
                c=stk.top();
                stk.pop();
            }
       }
       else{
           while(stk.top() != '$' && (stk.prec(exp[i]) < stk.prec(stk.top())) )
            {
                char c = stk.top();
                stk.pop();
                s += c;
            }
          stk.push(exp[i]);
       }
    } //for
     while(stk.top() != '$')
    {
        char c = stk.top();
        stk.pop();
        s += c;
    }


    cout<<s;
}
