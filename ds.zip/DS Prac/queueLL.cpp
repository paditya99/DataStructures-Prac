#include<iostream>
#include<bits/stdc++.h>
using namespace std;
class Node{
   public:
     int data;
     Node *next;

     Node(int data){
       this->data=data;
       next=NULL;
     }
};

class Queue{
  public:
      Node *front,*rear;

      Queue(){
        front=NULL;
        rear=NULL;
      }

      void enqueue(int data){
          Node *temp=new Node(data);

         if(front==NULL){
            front=temp;
            rear=temp;
         }
         else{
            rear->next=temp;
            rear=rear->next;
         }
      }

      Node* dequeue(){
          Node *temp;
         if(front==NULL){
            return NULL;
         }
         else{
            temp=front;
            delete temp;
            front=front->next;
            return temp;
         }
         if(front==NULL){
            rear==NULL;
         }
      }

      void display(){
              Node *temp=front;
              while(temp!=NULL){
                cout<<temp->data<<" ";
                temp=temp->next;
              }
         }

};

int main()
{
    Queue q;
    q.enqueue(3);
    q.enqueue(8);
    q.enqueue(4);
    q.enqueue(1);
    cout<<"The list is: ";
    q.display();

    Node* n = q.dequeue();
    n = q.dequeue();

    if (n != NULL)
        cout << "\nDequeued item is " << n->data;
    return 0;
}
