#include<iostream>
using namespace std;
class Node
{
    public:
    int data;
    Node *left, *right;

    Node(int value){
       data = value;
       left = NULL;
       right = NULL;
    }

};



Node* inserti(Node *root,int value){
 Node* newnode = new Node(value);

    Node* x = root;


    Node* y = NULL;

    while (x != NULL) {
        y = x;
        if (value < x->data){
            x = x->left;
        }
        else{
            x = x->right;
        }
    }


    if (y == NULL)
        y = newnode;

    else if (value< y->data)
        y->left = newnode;


    else
        y->right = newnode;

   return y;
}
void Inorder(Node* root)
{

    if (root == NULL)
        return;
    else {
        Inorder(root->left);
        cout << root->data << " ";
        Inorder(root->right);
    }
}

int main()
{


  Node *root=NULL;
 root=inserti(root,50);

    inserti(root,30);
    inserti(root,20);
    inserti(root,40);
    inserti(root,70);
    inserti(root,60);
    inserti(root,80);


    Inorder(root);

    return 0;
}
