#include<iostream>
#include<string.h>
using namespace std;
int main(){
   char st[]="this";
   int len=strlen(st);
   for(int i=len-1;i>=0;i--){
    cout<<st[i]<<"";
   }
}
