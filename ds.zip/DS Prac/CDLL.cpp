#include<iostream>
using namespace std;
class Node{
    public:
  Node *prev;
  Node *next;
  int data;
};
class CDLL{
   private:
     Node *start,*last;
   public:
     CDLL(){
       start=NULL;
       last=NULL;
     }
   void addatbeg(int value){
     Node *temp=new Node;
     temp->data=value;
     if(start==NULL){
       start=last=temp;
       start->next = last->next = NULL;
       start->prev = last->prev = NULL;
     }
     else{
        temp->next = start;
        start->prev = temp;
        start = temp;
        start->prev = last;
        last->next = start;
       }
       cout<<"add at beginning  ";
   }

   void addatend(int value){
       Node *temp=new Node;
       temp->data=value;
      if(start==NULL){
       start=last=temp;
       start->next = last->next = NULL;
       start->prev = last->prev = NULL;
     }
     else{
         last->next = temp;
        temp->prev = last;
        last = temp;
        start->prev = last;
        last->next = start;
     }
     cout<<"add at end  ";

   }

   void deleteatbeg(){
      int pos, i;
      Node *ptr, *s;
      s=start;
      if (start == last && start == NULL)
      {
        cout<<"List is empty, nothing to delete"<<endl;
        return;
      }
      else if(start==last){
        s=start;
        start=last=NULL;
        delete s;
      }
      else{
        last->next = s->next;
        last->prev = last;
        start = s->next;
        delete s;
      }
   }
   void deletefromend(){
     int pos, i;
      Node *ptr, *s;
      s=start;
      if (start == last && start == NULL)
      {
        cout<<"List is empty, nothing to delete"<<endl;
        return;
      }
      else if(start==last){
        s=start;
        start=last=NULL;
        delete s;
      }
      else{

        while(s-> next != start)
        {
            s=s->next;
        }
        s -> prev -> next = start;
        start -> prev = s -> prev;
        last=s->prev;
        delete s;
      }
   }
 void addsorted(int value){
          Node *temp=new Node;
          temp->data=value;
          if(start==NULL){

            start=temp;
            last=temp;
            last->next=start;
          }
          else if(start==last){
            if(value>start->data){
                start->next=temp;
                temp->prev=start;
                last=temp;
                last->next=start;
            }
            else{
                temp->next=start;
                start->prev=temp;
                start=temp;
                last=temp->next;
                last->next=start;
            }
          }
          else{
            if(value<start->data){
                temp->next=start;
                start->prev=temp;
                start=temp;



            }
            else if(value>last->data){
                Node *s;
                s=start;
                while(s->next!=start){
                s=s->next;
                }

                s->next=temp;
                temp->prev=s;
                last=temp;
                last->next=start;
              }
            else{
                Node *s;
                s=start;
                while(s!=last &&(s->data<value && s->next->data<value)){
                    s=s->next;
                }
                    if(s==start){
                    return;
                }
                else{
                    temp->next=s->next;
                    temp->prev=s;
                    s->next->prev=temp;
                     s->next=temp;
                }
            }
          }
          cout<<"add sorted  ";
      }


   void display()
 {
    int i;
    Node *s;
    if (start == last && start == NULL)
    {
        cout<<"The List is empty, nothing to display"<<endl;
        return;
    }
    s = start;
    while(s!=last){
        cout<<s->data<<" ";
        s = s->next;
    }
    cout<<s->data<<endl;
 }
void reverse()
 {
    int i;
    Node *s;
    if (start == last && start == NULL)
    {
        cout<<"The List is empty, nothing to display"<<endl;
        return;
    }
    s = last;
    while(s!=start){
        cout<<s->data<<" ";
        s = s->prev;
    }
    cout<<s->data<<endl;
 }




};
int main()
{
    CDLL a;

    int choice,value;
    char c;
    int pos;
    cout<<"\t*******CIRCULAR DOUBLY LINKED LIST OPERATIONS*******\t";

    cout<<"\n 1. add at head\n 2. add at tail\n 3. reverse the list\n 4. delete from beginning\n 5. delete from end\n 6. add sorted\n\n";
    do{
    cout<<"Enter your choice: ";
    cin>>choice;

    switch(choice){
       case 1:
          cout<<"Enter the element: ";
          cin>>value;
          a.addatbeg(value);
          a.display();
          cout<<"\n";
          break;
		case 2:
          cout<<"Enter the element: ";
          cin>>value;
          a.addatend(value);
          a.display();
          cout<<"\n";
		  break;
        case 3:

          a.reverse();

          cout<<"\n";
		  break;
        case 4:
            a.deleteatbeg();
            a.display();
            cout<<"\n";
            break;
        case 5:
            a.deletefromend();
            a.display();
            cout<<"\n";
            break;
        case 6:
            cout<<"Enter the element: ";
            cin>>value;
            a.addsorted(value);
            a.display();
            break;
        default:
          cout<<"WRONG INPUT, ENTER AGAION ";
          break;
     }
     cout<<"Do you want to continue? y/n : ";
     cin>>c;
     switch(c){
        case 'n':
           break;
         }
         }while(c=='y')  ;


 return 0;
}
