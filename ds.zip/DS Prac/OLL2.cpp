#include<iostream>
using namespace std;
class Node{
  public:
    int data;
    Node* next;
};
class linkedlist{
    public:
        Node* head,*tail;
    public:

    linkedlist(){
       head=NULL;
       tail=NULL;
    }

    void insertion(int data){


        if(head==NULL){
            Node *temp=new Node();
            temp->data=data;
            temp->next=head;
            head=temp;
            tail=temp;
        }
        else if(head->data > data){
            Node *temp=new Node();
            temp->data=data;
            temp->next=head;
            head=temp;

        }
        else{
            Node *temp=head;
            while(temp->next !=NULL && temp->next->data < data){
                temp=temp->next;

            }

            Node *n=new Node();
            n->data=data;
            n->next=temp->next;
            temp->next=n;



        }


    }
Node* taili(){
            Node *t=head;
            while(t!=NULL){
                tail=tail->next;
            }


}


    void deletion(int data){
       if(head==NULL){
        cout<<"There are no items in the list";
        return;
       }
      else if(head->data==data){
        Node *d=head;
        head=head->next;

        delete d;

       }
       else{

      Node *temp=head;
      while(temp->next!=NULL && temp->next->data!=data){
        temp=temp->next;
      }
      Node *del;
      del=temp->next;
      temp->next=del->next;
      delete del;
     }

    }





     void display()
    {
        Node *N;
        N=head;
        while(N!=NULL)
        {

        cout<<N->data<<" ";
        N=N->next;
        }
    }

};

void merge(linkedlist l1,linkedlist l2){

    Node* head2=l2.head;
    l1.tail->next=l2.head;
    l1.tail=l2.tail;
}

int main(){
    linkedlist l1,l2,l3;
  Node *next=NULL;
  Node* head = NULL;
  linkedlist l;
  l1.insertion(10);
  l1.insertion(40);
  l1.insertion(70);
  l1.taili();
cout<<"The first list: ";
  l1.display();

  l2.insertion(20);
  l2.insertion(30);
  l2.insertion(50);
  cout<<"\nThe second list: ";
  l2.display();

  cout<<"\nAfter merging: ";
  merge(l1,l2);
  l1.display();

}
