#include<iostream>
using namespace std;
int main(){
  int temp,j,i;
  int arr[6]={4,9,1,6,12,3};
  for(i=0;i<6;i++){
    for(j=i+1;j<6;j++){
        if(arr[j]<arr[i]){
            temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }
  }
   for(int i=0;i<6;i++){
    cout<<arr[i]<<" ";
  }


  }
