#include <iostream>
using namespace std;

void printFibonacci(int n){
    static int n1=0, n2=1, n3;
    if(n>0){
         n3 = n1 + n2;
         n1 = n2;
         n2 = n3;
         cout<<n3<<" ";
         printFibonacci(n-1);
    }
}

int main() {
  int n1=0,n2=1,n3,i,number,ch;
 cout<<"Enter the number of elements: ";
 cin>>number;

 cout<<"\n1. using iteration: ";
 cout<<"\n2. using recursion: ";
 cout<<"\nEnter your choice: ";
 cin>>ch;
 switch(ch){
    case 1:
        cout<<n1<<" "<<n2<<" ";
        for(i=2;i<number;++i)
        {
          n3=n1+n2;
          cout<<n3<<" ";
          n1=n2;
          n2=n3;
        }
        break;
    case 2:
        cout<<"Fibonacci Series: ";
        cout<<"0 "<<"1 ";
        printFibonacci(number-2);
        break;
    default:
        cout<<"Wrong Input, Enter again: ";
 }

   return 0;
   }
