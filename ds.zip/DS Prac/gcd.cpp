#include <iostream>
using namespace std;

int hcf(int a, int b)
{
    while (a != b) {
        if (a > b)
            a = a - b;
        else
            b = b - a;
    }
    return a;
}

int gcd(int a, int b)
{

    if (a == 0)
       return b;
    if (b == 0)
       return a;

    if (a == b)
        return a;


    if (a > b)
        return gcd(a-b, b);
    return gcd(a, b-a);
}


int main()
{
    int a,b,ch;
    cout<<"Enter the two numbers: ";
    cin>>a;
    cin>>b;
    cout<<"\n1. using iteration: ";
    cout<<"\n2. using recursion: ";
    cout<<"\nEnter your choice: ";
    cin>>ch;
    switch(ch){
        case 1:
            cout<<hcf(a, b);
            break;
        case 2:
            cout<<gcd(a,b);
            break;
        default:
            cout<<"Wrong Input, Enter again: ";
    }

    return 0;
}
