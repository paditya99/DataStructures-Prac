#include<iostream>
#define MAX 10
#include<bits/stdc++.h>
using namespace std;
class Node{
   public:
     int data;
};

class Queue{

  public:
       int front,rear;
      int q[MAX];
     Queue(){
        front=-1;
        rear=-1;

     }
     bool isfull(){
        if(rear==MAX-1){
            return true;
        }
        else{
            return false;
        }
     }
     bool isempty(){
        if(front==0 || rear==-1){
            return true;
        }
        else{
            return false;
        }
     }
     void enqueue(int data){
       if(!isfull()){
        front=0;
        rear++;
        q[rear]=data;
       }
       else{
        cout<<"The queue is full";
       }

     }

    int fronti(){
       return q[rear];

     }

     int dequeue()
   {
            cout<<"The dequeue is going to be: "<<q[front];
            front++;


     }





};
int main(){
   Queue qu;
   int i;
   qu.enqueue(2);
   qu.enqueue(5);
   qu.enqueue(1);
   qu.enqueue(6);


   cout<<"Before dequeue: ";

    for(i=qu.front;i<=qu.rear;i++){
        cout<<qu.q[i]<<" ";
    }
   qu.dequeue();


   cout<<"\nAfter dequeue: ";
   for(i=qu.front;i<=qu.rear;i++){
        cout<<qu.q[i]<<" ";
    }


}

